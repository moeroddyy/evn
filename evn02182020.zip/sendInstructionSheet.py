from classes import sendInstructionSheetProgram


temp = sendInstructionSheetProgram()
temp.startProgram()

