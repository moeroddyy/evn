from . import *


class Email:

	def __init__(self):
		self.server = smtplib.SMTP('smtp.gmail.com: 587')
		self.server.ehlo()
		self.server.starttls()
		self.server.login("moe@evonifyllc.com", "Mohammed@Elkhatib1995")

	def sendEmail(self,subject,msg):
		try:
			message = 'Subject: {}\n\n{}'.format(subject, msg)
			self.server.sendmail('moe@evonifyllc.com','moe@evonifyllc.com',message)
			print("email has been sent")
			self.server.quit()
		except Exception as e:
			print("email couldn't be send due to an error")
			print(e)

