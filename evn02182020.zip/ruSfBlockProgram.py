from classes import sendInstructionSheetProgram, sfRuCalendarBlock



temp = sfRuCalendarBlock()
temp.startProgram()