from classes import airbnbSfSync, airbnbScraper, sForce


scraper1 = airbnbScraper("1")
reservationsDict = scraper1.startScraping('1',0) #0 for scrape on mac #1 for scrape on server
sforce = sForce()
addData = airbnbSfSync(scraper1, sforce, reservationsDict)

